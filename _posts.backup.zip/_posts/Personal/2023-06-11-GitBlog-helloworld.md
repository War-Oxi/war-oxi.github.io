---
title: 블로그의 방향성
date: 2023-06-11 20:37:00 +0900
author: kkankkandev
categories: [Personal]
tags: [kkankkandev]     # TAG names should always be lowercase
comments: true
pin: true
image: 
    path: https://github.com/War-Oxi/war-oxi.github.io/assets/72260110/87055239-475b-4e8c-b3e5-c8fe594a2063
---

## Github Blog

- 공부 기록 후 복습  
- 나와 같은 문제를 겪는 사람들이 이 블로그를 통해 문제를 해결 할 수 있길바라며.. ~~(삽질 그만)~~  
- git + markdown 공부가 자연스레..?? (1석 2조) [ 돌 하나에 2조?? ㄷㄷㄷ ]  

> Written with [KKam.\_\.Ji](https://www.instagram.com/kkam._.ji/)
{: .prompt-info}
